<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Contact - Gratisco</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Muli:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Flattern - v4.7.0
  * Template URL: https://bootstrapmade.com/flattern-multipurpose-bootstrap-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Top Bar ======= -->
  <section id="topbar" class="d-flex align-items-center">
    <div class="container d-flex justify-content-center justify-content-md-between">
      <div class="contact-info d-flex align-items-center">
        <i class="bi bi-envelope d-flex align-items-center"><a href="mailto:contact@example.com">contact@example.com</a></i>
        <i class="bi bi-phone d-flex align-items-center ms-4"><span>+1 5589 55488 55</span></i>
      </div>
      <div class="social-links d-none d-md-flex align-items-center">
        <a href="#" class="twitter"><i class="bi bi-twitter"></i></a>
        <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
        <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
        <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></i></a>
      </div>
    </div>
  </section>

  <!-- ======= Header ======= -->
  <header id="header" class="d-flex align-items-center">
    <div class="container d-flex justify-content-between">

      <div class="logo">
        <h1 class="text-light"><a href="index.html">Gratisco</a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="active" href="index.html">Home</a></li>
          <li><a href="about.html">About</a></li>
          <li class="dropdown"><a href="services.html"><span>Services</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="services.html">Swimming Pool Water Treatment Plant</a></li>
              <li><a href="services.html">Effluent Treatment Plant (ETP)</a></li>
              <li><a href="services.html">Sewage Treatment Plant (STP)</a></li>
              <li><a href="services.html">Industrial Water Treatment Plant (IWTP)</a></li>
              <li><a href="services.html">Rain Water Harvesting Plant (RWHP)</a></li>
              <li><a href="services.html">Water Softener Plant</a></li>
              <li><a href="services.html">High Grade Iron Removal Filter</a></li>
              <li><a href="services.html">Activated Carbon Filter (ACF)</a></li>
              <li><a href="services.html">Dimeneralised (DM Plant)</a></li>
                         </ul>
          </li>

          <li class="dropdown"><a href="products.html"><span>Products</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="WSF.html">Whole House Filtration</a></li>
              <li><a href="RP.html">RO Plant</a></li>
              <li><a href="ASP.html">All Spare Parts</a></li>
            </ul>
          </li>
          <li><a href="pricing.html">Pricing</a></li>
    
          <li><a href="contact.html">Contact</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Contact</h2>
          <ol>
            <li><a href="index.html">Home</a></li>
            <li>Contact</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->

    <!-- ======= Contact Section ======= -->
    <div class="map-section">
      <iframe style="border:0; width: 100%; height: 350px;" src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d12097.433213460943!2d-74.0062269!3d40.7101282!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xb89d1fe6bc499443!2sDowntown+Conference+Center!5e0!3m2!1smk!2sbg!4v1539943755621" frameborder="0" allowfullscreen></iframe>
    </div>

    <section id="contact" class="contact">
      <div class="container">

        <div class="row justify-content-center" data-aos="fade-up">

          <div class="col-lg-10">

            <div class="info-wrap">
              <div class="row">
                <div class="col-lg-4 info">
                  <i class="bi bi-geo-alt"></i>
                  <h4>Location:</h4>
                  <p>A108 Adam Street<br>New York, NY 535022</p>
                </div>

                <div class="col-lg-4 info mt-4 mt-lg-0">
                  <i class="bi bi-envelope"></i>
                  <h4>Email:</h4>
                  <p>info@example.com<br>contact@example.com</p>
                </div>

                <div class="col-lg-4 info mt-4 mt-lg-0">
                  <i class="bi bi-phone"></i>
                  <h4>Call:</h4>
                  <p>+1 5589 55488 51<br>+1 5589 22475 14</p>
                </div>
              </div>
            </div>

          </div>

        </div>

        <div class="row mt-5 justify-content-center" data-aos="fade-up">
          <div class="col-lg-10">
            <form action="forms/contact.php" method="post" role="form" class="php-email-form">
              <div class="row">
                <div class="col-md-6 form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" required>
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" required>
                </div>
              </div>
              <!-- <div class="form-group mt-3">
                <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" required>
              </div> -->
              
                <div class="row">
                  <div class="col-md-6 form-group">
              <label for="category">Category:</label>
		
	
              <select name="category" id="category" onChange="categoryshow();">
			  <option value="">Select</option>
                <option value="whole">Whole House Filtration</option>
                <option value="ro">RO Plant</option>
                <option value="spare">All Spare Parts</option>
              </select> 
</div>
<style>
.subcategory
{
	display:none;
}
</style>
  <div class="subcategory"  id="whole" >
  <div class="col-md-6 form-group">
<select name="whole" id="whole" >
    <label for="category">Whole House Filtration</label>
  <option value="volvo">IRF1354 TOP (Upto 500LPH)</option>
  <option value="saab">IRF1465 TOP (Upto 1000LPH)</option>
  <option value="mercedes">IRF1465 TB (Upto 1000LPH)</option>
  <option value="volvo">IRF1665 TB (Upto 2000LPH)</option>
                <option value="saab">IRF1865 TB (Upto 3000LPH)</option>
                <option value="mercedes">IRF2162 TB (Upto 4000LPH)</option>
                <option value="volvo">IRF2472 TB (Upto 6000LPH)</option>
                <option value="saab">IRF3072 TB (Upto 8000LPH)</option>
                <option value="mercedes">IRF3672 TB (Upto 12000LPH)</option>
                <option value="volvo">IRF4272 TB (Upto 15000LPH)</option>
                <option value="saab">IRF4872 TB (Upto 20000LPH)</option>
                <option value="mercedes">IRF6472 TB (Upto 30000LPH)</option>
  </select>
  </div>
  </div>
  
  <div class="subcategory"  id="RO">
  <div class="col-md-6 form-group">
<select name="RO" id="RO">
 <label for="category">RO Plant</label>
  <option value="volvo">100LPH RO Plant</option>
                <option value="saab">250LPH RO Plant</option>
                <option value="mercedes">500LPH RO Plant</option>
                <option value="volvo">1000LPH RO Plant</option>
                <option value="saab">2000LPH RO Plant</option>
                <option value="mercedes">3000LPH RO Plant</option>
                <option value="volvo">4000LPH RO Plant</option>
                <option value="saab">5000LPH RO Plant</option>
                <option value="mercedes">RO with UV Plant</option>
  </select>
  </div>
  </div>
  <div class="subcategory" id="Spare">
   <label for="category">All Spare Parts</label>
<select name="Spare" id="Spare">
                <option value="volvo">FRP Vessels</option>
                <option value="saab">Multiport Valves (MPV)</option>
                <option value="mercedes">Distribution/Strainer</option>
                <option value="volvo">Filter Media</option>
                <option value="saab">RO Membrane & Housing</option>
                <option value="mercedes">Pumps</option>
                <option value="volvo">Micron Filter</option>
                <option value="saab">RO Panel Board</option>
                <option value="mercedes">Chemical</option>
                <option value="volvo">UV System</option>
                <option value="saab">SS Tank</option>
                <option value="mercedes">Rota Meter</option>
                <option value="volvo">Other Accessories</option>
  </select>
  </div>
                <!-----------------RO Plant-----------------
                
                <!---------End---------->
                <!----------------All Spare Parts----------------
                <option value="volvo">FRP Vessels</option>
                <option value="saab">Multiport Valves (MPV)</option>
                <option value="mercedes">Distribution/Strainer</option>
                <option value="volvo">Filter Media</option>
                <option value="saab">RO Membrane & Housing</option>
                <option value="mercedes">Pumps</option>
                <option value="volvo">Micron Filter</option>
                <option value="saab">RO Panel Board</option>
                <option value="mercedes">Chemical</option>
                <option value="volvo">UV System</option>
                <option value="saab">SS Tank</option>
                <option value="mercedes">Rota Meter</option>
                <option value="volvo">Other Accessories</option>
                <!-----------End------------
</select> 
</div>
<div class="row">
  <div class="col-md-6 form-group">
<label for="cars">Industrial Plant/Services:</label>
<select name="cars" id="cars">
<option value="volvo">Swimming Pool Water Treatment Plant</option>
<option value="saab">Effluent Treatment Plant (ETP)</option>
<option value="mercedes">Sewage Treatment Plant (STP)</option><input type="text">
<option value="volvo">Industrial Water Treatment Plant (IWTP)</option>
<option value="saab">Rain Water Harvesting Plant (RWHP)</option>
<option value="mercedes">Water Softener Plant</option>
<option value="volvo">High Grade Iron Removal Filter</option>
<option value="saab">Activated Carbon Filter (ACF)</option>
<option value="mercedes">Dimeneralised (DM Plant)</option>

</select> 
</div>
-->
              <div class="form-group mt-3">
                <textarea class="form-control" name="message" rows="5" placeholder="Message" required></textarea>
              </div>
              <div class="my-3">
                <div class="loading">Loading</div>
                <div class="error-message"></div>
                <div class="sent-message">Your message has been sent. Thank you!</div>
              </div>
              <div class="text-center"><button type="submit">Send Message</button></div>
            </form>
          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->
<script>
function categoryshow()
{
	var cat=document.getElementById("category");
	var va=cat.value;
	//alert(va);
	if(va== "whole")
	{
		alert("Enter in if");
		var x=document.getElementById("whole");
		x.style.display="block";
	}
	if(va== "ro")
	{
		alert("Enter in if");
		var x=document.getElementById("RO");
		x.style.display="block";
	}
	if(va== "spare")
	{
		alert("Enter in if");
		var x=document.getElementById("Spare");
		x.style.display="block";
	}

}
</script>
  <!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-contact">
            <h3>Gratisco</h3>
            <p>
              A108 Adam Street <br>
              New York, NY 535022<br>
              United States <br><br>
              <strong>Phone:</strong> +1 5589 55488 55<br>
              <strong>Email:</strong> info@example.com<br>
            </p>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="index.html">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="about.html">About us</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="services.html">Services</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="products.html">Products</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="pricing.html">Pricing</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="contact.html">Contact</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Our Services</h4>
            <ul>
              <li><a href="services.html">Swimming Pool Water Treatment Plant</a></li>
              <li><a href="services.html">Effluent Treatment Plant (ETP)</a></li>
              <li><a href="services.html">Sewage Treatment Plant (STP)</a></li>
              <li><a href="services.html">Industrial Water Treatment Plant (IWTP)</a></li>
              <li><a href="services.html">Rain Water Harvesting Plant (RWHP)</a></li>
              <li><a href="services.html">Water Softener Plant</a></li>
              <li><a href="services.html">High Grade Iron Removal Filter</a></li>
              <li><a href="services.html">Activated Carbon Filter (ACF)</a></li>
              <li><a href="services.html">Dimeneralised (DM Plant)</a></li>
            </ul>
          </div>

          <div class="col-lg-4 col-md-6 footer-newsletter">
            <h4>Join Our Newsletter</h4>
            <p>Tamen quem nulla quae legam multos aute sint culpa legam noster magna</p>
            <form action="" method="post">
              <input type="email" name="email"><input type="submit" value="Subscribe">
            </form>
          </div>

        </div>
      </div>
    </div>

    <div class="container d-md-flex py-4">

      <div class="me-md-auto text-center text-md-start">
        <div class="copyright">
          &copy; Copyright <strong><span>Gratisco</span></strong>. All Rights Reserved
        </div>
        <div class="credits">
          <!-- All the links in the footer should remain intact. -->
          <!-- You can delete the links only if you purchased the pro version. -->
          <!-- Licensing information: https://bootstrapmade.com/license/ -->
          <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/flattern-multipurpose-bootstrap-template/ -->
          Designed by <a href="https://adctechno.com/">ADC Technologies</a>
        </div>
      </div>
      <div class="social-links text-center text-md-right pt-3 pt-md-0">
        <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
        <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
        <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
        <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/waypoints/noframework.waypoints.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>